"use strict";(()=>{var e={};e.id=306,e.ids=[306],e.modules={72934:e=>{e.exports=require("next/dist/client/components/action-async-storage.external.js")},54580:e=>{e.exports=require("next/dist/client/components/request-async-storage.external.js")},45869:e=>{e.exports=require("next/dist/client/components/static-generation-async-storage.external.js")},20399:e=>{e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},30517:e=>{e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},32615:e=>{e.exports=require("http")},35240:e=>{e.exports=require("https")},68621:e=>{e.exports=require("punycode")},76162:e=>{e.exports=require("stream")},17360:e=>{e.exports=require("url")},71568:e=>{e.exports=require("zlib")},22905:(e,r,t)=>{t.r(r),t.d(r,{originalPathname:()=>f,patchFetch:()=>h,requestAsyncStorage:()=>c,routeModule:()=>m,serverHooks:()=>g,staticGenerationAsyncStorage:()=>p});var a={};t.r(a),t.d(a,{GET:()=>_});var s=t(49303),o=t(88716),i=t(60670),u=t(87070),l=t(6943),n=t(202);class d{static async createHourlyRate(e,r){try{let t=(0,l.K)(),{data:a,error:s}=await t.from("groups").select("id").eq("id",r.group_id).eq("manager_id",e).single();if(s||!a)return{data:null,error:"Unauthorized to set rates for this group"};let{data:o,error:i}=await t.from("group_memberships").select("id").eq("group_id",r.group_id).eq("user_id",r.user_id).single();if(i||!o)return{data:null,error:"User is not a member of this group"};let u={group_id:r.group_id,user_id:r.user_id,set_by:e,hourly_rate:r.hourly_rate,currency:r.currency||"USD",effective_from:r.effective_from||new Date().toISOString(),is_active:!0},{data:n,error:d}=await t.from("hourly_rates").insert([u]).select().single();if(d)return{data:null,error:d.message};return{data:n,error:null}}catch(e){return{data:null,error:"Failed to create hourly rate"}}}static async getHourlyRate(e){try{let r=(0,l.K)(),{data:t,error:a}=await r.from("hourly_rates").select(`
          *,
          user_profile:user_profiles!user_id(
            full_name,
            email
          ),
          set_by_profile:user_profiles!set_by(
            full_name
          ),
          group:groups!group_id(
            name
          )
        `).eq("id",e).single();if(a)return{data:null,error:a.message};return{data:{...t,user_name:t.user_profile?.full_name,user_email:t.user_profile?.email,set_by_name:t.set_by_profile?.full_name,group_name:t.group?.name},error:null}}catch(e){return{data:null,error:"Failed to fetch hourly rate"}}}static async getGroupHourlyRates(e){try{let r=(0,l.K)(),{data:t,error:a}=await r.from("hourly_rates").select(`
          *,
          user_profile:user_profiles!user_id(
            full_name,
            email
          ),
          set_by_profile:user_profiles!set_by(
            full_name
          )
        `).eq("group_id",e).eq("is_active",!0).order("created_at",{ascending:!1});if(a)return{data:[],error:a.message};return{data:(t||[]).map(e=>({...e,user_name:e.user_profile?.full_name,user_email:e.user_profile?.email,set_by_name:e.set_by_profile?.full_name})),error:null}}catch(e){return{data:[],error:"Failed to fetch group hourly rates"}}}static async getUserHourlyRate(e,r){try{let t=(0,l.K)(),{data:a,error:s}=await t.from("hourly_rates").select(`
          *,
          user_profile:user_profiles!user_id(
            full_name,
            email
          ),
          set_by_profile:user_profiles!set_by(
            full_name
          ),
          group:groups!group_id(
            name
          )
        `).eq("group_id",e).eq("user_id",r).eq("is_active",!0).single();if(s)return{data:null,error:s.message};return{data:{...a,user_name:a.user_profile?.full_name,user_email:a.user_profile?.email,set_by_name:a.set_by_profile?.full_name,group_name:a.group?.name},error:null}}catch(e){return{data:null,error:"Failed to fetch user hourly rate"}}}static async updateHourlyRate(e,r){try{let t=(0,l.K)(),a={};void 0!==r.hourly_rate&&(a.hourly_rate=r.hourly_rate),void 0!==r.currency&&(a.currency=r.currency),void 0!==r.effective_from&&(a.effective_from=r.effective_from),void 0!==r.effective_until&&(a.effective_until=r.effective_until);let{data:s,error:o}=await t.from("hourly_rates").update(a).eq("id",e).select().single();if(o)return{data:null,error:o.message};return{data:s,error:null}}catch(e){return{data:null,error:"Failed to update hourly rate"}}}static async deactivateHourlyRate(e){try{let r=(0,l.K)(),{error:t}=await r.from("hourly_rates").update({is_active:!1,effective_until:new Date().toISOString()}).eq("id",e);if(t)return{error:t.message};return{error:null}}catch(e){return{error:"Failed to deactivate hourly rate"}}}static async deleteHourlyRate(e){try{let r=(0,l.K)(),{error:t}=await r.from("hourly_rates").delete().eq("id",e);if(t)return{error:t.message};return{error:null}}catch(e){return{error:"Failed to delete hourly rate"}}}static async getHourlyRateHistory(e,r){try{let t=(0,l.K)(),{data:a,error:s}=await t.from("hourly_rates").select(`
          *,
          user_profile:user_profiles!user_id(
            full_name,
            email
          ),
          set_by_profile:user_profiles!set_by(
            full_name
          )
        `).eq("group_id",e).eq("user_id",r).order("created_at",{ascending:!1});if(s)return{data:null,error:s.message};let o=(a||[]).map(e=>({...e,user_name:e.user_profile?.full_name,user_email:e.user_profile?.email,set_by_name:e.set_by_profile?.full_name})),i=o.find(e=>e.is_active);return{data:{rates:o,current_rate:i,total_changes:o.length},error:null}}catch(e){return{data:null,error:"Failed to fetch hourly rate history"}}}static async calculateEarnings(e,r,t,a,s=!1){try{let s=(0,l.K)(),{data:o}=await this.getUserHourlyRate(e,r);if(!o)return{data:null,error:"No hourly rate found for user"};let{data:i,error:u}=await s.from("time_entries").select("duration_minutes, clock_in, clock_out").eq("user_id",r).eq("group_id",e).gte("clock_in",t).lte("clock_in",a).not("clock_out","is",null);if(u)return{data:null,error:u.message};let n=(i||[]).reduce((e,r)=>e+(r.duration_minutes||0),0)/60,d=n,_=0;n>40&&(d=40,_=n-40);let m=d*o.hourly_rate,c=_*o.hourly_rate*1.5;return{data:{user_id:r,user_name:o.user_name,hours_worked:n,regular_hours:d,overtime_hours:_,hourly_rate:o.hourly_rate,regular_earnings:m,overtime_earnings:c,total_earnings:m+c,currency:o.currency,period_start:t,period_end:a},error:null}}catch(e){return{data:null,error:"Failed to calculate earnings"}}}static async calculateGroupEarnings(e,r,t,a=!1){try{let s=(0,l.K)(),{data:o,error:i}=await s.from("group_memberships").select("user_id").eq("group_id",e);if(i)return{data:[],error:i.message};let u=[];for(let s of o||[]){let{data:o,error:i}=await this.calculateEarnings(e,s.user_id,r,t,a);o&&!i&&u.push(o)}return{data:u,error:null}}catch(e){return{data:[],error:"Failed to calculate group earnings"}}}}async function _(e,{params:r}){try{let t=(0,l.K)(),{data:{session:a}}=await t.auth.getSession();if(!a)return u.NextResponse.json({error:"Unauthorized"},{status:401});let{searchParams:s}=new URL(e.url),o=s.get("start_date"),i=s.get("end_date"),_="true"===s.get("include_earnings"),m="true"===s.get("california_mode"),{data:c,error:p}=await n.l.getGroup(r.id);if(p||!c)return u.NextResponse.json({error:"Group not found or unauthorized"},{status:404});let g=c.manager_id===a.user.id,f=c.memberships?.some(e=>e.user_id===a.user.id);if(!g&&!f)return u.NextResponse.json({error:"Unauthorized to view group reports"},{status:403});let h=t.from("time_entries").select(`
        *,
        user_profiles!inner(
          full_name,
          email
        )
      `).eq("group_id",r.id).not("clock_out","is",null);o&&(h=h.gte("clock_in",o)),i&&(h=h.lte("clock_in",i));let{data:y,error:b}=await h;if(b)return u.NextResponse.json({error:b.message},{status:400});let v=(y||[]).reduce((e,r)=>{let t=r.user_id;return e[t]||(e[t]={user_id:t,user_name:r.user_profiles?.full_name||"Unknown",user_email:r.user_profiles?.email,total_minutes:0,total_hours:0,entries:[]}),e[t].total_minutes+=r.duration_minutes||0,e[t].total_hours=e[t].total_minutes/60,e[t].entries.push(r),e},{}),w=Object.values(v);if(_&&g&&o&&i){let e=w.map(async e=>{let{data:t}=await d.calculateEarnings(r.id,e.user_id,o,i,m);return{...e,earnings:t}}),t=await Promise.all(e);return u.NextResponse.json({group_report:{group_id:r.id,group_name:c.name,period:{start_date:o,end_date:i},generated_at:new Date().toISOString(),generated_by:a.user.id,california_mode:m,members:t,summary:{total_members:t.length,total_hours:t.reduce((e,r)=>e+r.total_hours,0),total_earnings:t.reduce((e,r)=>e+(r.earnings?.total_earnings||0),0)}}})}return u.NextResponse.json({group_report:{group_id:r.id,group_name:c.name,period:{start_date:o,end_date:i},generated_at:new Date().toISOString(),generated_by:a.user.id,members:w,summary:{total_members:w.length,total_hours:w.reduce((e,r)=>e+r.total_hours,0)}}})}catch(e){return console.error("Get group report API error:",e),u.NextResponse.json({error:"Internal server error"},{status:500})}}let m=new s.AppRouteRouteModule({definition:{kind:o.x.APP_ROUTE,page:"/api/v1/reports/group/[id]/route",pathname:"/api/v1/reports/group/[id]",filename:"route",bundlePath:"app/api/v1/reports/group/[id]/route"},resolvedPagePath:"D:\\-=DropboxDoNotDelete=-\\Dropbox\\MyExecAssistant\\00-Github-SpecKit+\\timetracker\\src\\app\\api\\v1\\reports\\group\\[id]\\route.ts",nextConfigOutput:"standalone",userland:a}),{requestAsyncStorage:c,staticGenerationAsyncStorage:p,serverHooks:g}=m,f="/api/v1/reports/group/[id]/route";function h(){return(0,i.patchFetch)({serverHooks:g,staticGenerationAsyncStorage:p})}},6943:(e,r,t)=>{t.d(r,{K:()=>o});var a=t(67721),s=t(71615);let o=()=>{let e=(0,s.cookies)();return(0,a.createServerClient)("https://kgwklydkmeihoulipqof.supabase.co","eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imtnd2tseWRrbWVpaG91bGlwcW9mIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTg3MjgwOTksImV4cCI6MjA3NDMwNDA5OX0.SVsGhRHEcRCArfKYwHbw2tWDfoF1JG8kaUm1cIgIOB4",{cookies:{get:r=>e.get(r)?.value,set(r,t,a){e.set({name:r,value:t,...a})},remove(r,t){e.delete({name:r,...t})}}})}},202:(e,r,t)=>{t.d(r,{l:()=>s});var a=t(6943);class s{static async createGroup(e,r){try{let t=(0,a.K)(),s={name:r.name,description:r.description||null,manager_id:e,max_members:r.max_members||3},{data:o,error:i}=await t.from("groups").insert([s]).select().single();if(i)return{data:null,error:i.message};return{data:o,error:null}}catch(e){return{data:null,error:"Failed to create group"}}}static async getGroup(e){try{let r=(0,a.K)(),{data:t,error:s}=await r.from("groups").select(`
          *,
          memberships:group_memberships(
            id,
            user_id,
            role,
            joined_at,
            user_profiles!inner(
              full_name,
              email
            )
          )
        `).eq("id",e).single();if(s)return{data:null,error:s.message};return{data:{...t,member_count:t.memberships?.length||0,memberships:t.memberships||[]},error:null}}catch(e){return{data:null,error:"Failed to fetch group"}}}static async getUserGroups(e){try{let r=(0,a.K)(),{data:t,error:s}=await r.from("groups").select(`
          *,
          memberships:group_memberships(
            id,
            user_id,
            role,
            joined_at,
            user_profiles!inner(
              full_name,
              email
            )
          )
        `).or(`manager_id.eq.${e},id.in.(${await this.getUserGroupIds(e)})`);if(s)return{data:[],error:s.message};return{data:(t||[]).map(e=>({...e,member_count:e.memberships?.length||0,memberships:e.memberships||[]})),error:null}}catch(e){return{data:[],error:"Failed to fetch user groups"}}}static async getUserGroupIds(e){try{let r=(0,a.K)(),{data:t,error:s}=await r.from("group_memberships").select("group_id").eq("user_id",e);if(s||!t)return"";return t.map(e=>e.group_id).join(",")}catch(e){return""}}static async updateGroup(e,r){try{let t=(0,a.K)(),s={};void 0!==r.name&&(s.name=r.name),void 0!==r.description&&(s.description=r.description),void 0!==r.max_members&&(s.max_members=r.max_members);let{data:o,error:i}=await t.from("groups").update(s).eq("id",e).select().single();if(i)return{data:null,error:i.message};return{data:o,error:null}}catch(e){return{data:null,error:"Failed to update group"}}}static async deleteGroup(e){try{let r=(0,a.K)(),{error:t}=await r.from("groups").delete().eq("id",e);if(t)return{error:t.message};return{error:null}}catch(e){return{error:"Failed to delete group"}}}static async addMember(e,r){try{let t=(0,a.K)(),{data:s}=await t.from("group_memberships").select("id").eq("group_id",e),{data:o}=await t.from("groups").select("max_members").eq("id",e).single();if(s&&o&&s.length>=o.max_members)return{data:null,error:"Group is at maximum capacity"};let i={group_id:e,user_id:r.user_id,role:r.role||"member"},{data:u,error:l}=await t.from("group_memberships").insert([i]).select().single();if(l)return{data:null,error:l.message};return{data:u,error:null}}catch(e){return{data:null,error:"Failed to add member"}}}static async removeMember(e,r){try{let t=(0,a.K)(),{error:s}=await t.from("group_memberships").delete().eq("group_id",e).eq("user_id",r);if(s)return{error:s.message};return{error:null}}catch(e){return{error:"Failed to remove member"}}}static async updateMemberRole(e,r,t){try{let s=(0,a.K)(),{data:o,error:i}=await s.from("group_memberships").update({role:t.role}).eq("group_id",e).eq("user_id",r).select().single();if(i)return{data:null,error:i.message};return{data:o,error:null}}catch(e){return{data:null,error:"Failed to update member role"}}}static async getGroupMembers(e){try{let r=(0,a.K)(),{data:t,error:s}=await r.from("group_memberships").select(`
          id,
          user_id,
          role,
          joined_at,
          user_profiles!inner(
            full_name,
            email
          ),
          hourly_rates(
            hourly_rate,
            currency,
            is_active
          )
        `).eq("group_id",e).eq("hourly_rates.is_active",!0);if(s)return{data:[],error:s.message};return{data:(t||[]).map(e=>({id:e.id,user_id:e.user_id,full_name:e.user_profiles?.full_name,email:e.user_profiles?.email,role:e.role,joined_at:e.joined_at,hourly_rate:e.hourly_rates?.[0]?.hourly_rate,currency:e.hourly_rates?.[0]?.currency})),error:null}}catch(e){return{data:[],error:"Failed to fetch group members"}}}static async getGroupStats(e,r,t){try{let s=(0,a.K)(),{data:o}=await s.from("group_memberships").select("id").eq("group_id",e),i=s.from("time_entries").select("duration_minutes, user_id").eq("group_id",e).not("clock_out","is",null);r&&(i=i.gte("clock_in",r)),t&&(i=i.lte("clock_in",t));let{data:u}=await i,l=u?.reduce((e,r)=>e+(r.duration_minutes||0),0)||0;return{data:{total_members:o?.length||0,active_members:o?.length||0,total_hours_today:0,total_hours_week:l/60},error:null}}catch(e){return{data:null,error:"Failed to fetch group stats"}}}}}};var r=require("../../../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),a=r.X(0,[9276,5972,9498,9702],()=>t(22905));module.exports=a})();
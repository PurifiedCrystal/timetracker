# Progress Recorder Pack (100%)

Files:
- `CLAUDE.md` — triggers, matrices, recap template, archive guards
- `progress.md` — working memory
- `progress.archive.md` — append-only history
- `.claude/agents/progress-recorder.md` — system prompt (100%)
- `.claude/agents/progress-recorder.when-to-use.txt` — agent Description

Setup:
1) Copy into your project root (keep paths).
2) Claude Code → /agents → Create **progress-recorder** (Project scope).
3) Paste system prompt & description; enable file read/write.
4) Test:  
   - “We decided to use Next.js; we must support Safari.” → `/record`  
   - “We finished auth (PR #42).” → `/record`  
   - `/recap` → standardized recap  
   - Add many Notes/Done → `/archive`

_Last updated: 2025-09-24 08:00_
